import authenticationRouter from "./authenticationRoutes";
import { bookRouter } from "./bookRoutes";
import { noteRouter } from "./noteRouter";

export { bookRouter, authenticationRouter, noteRouter };
